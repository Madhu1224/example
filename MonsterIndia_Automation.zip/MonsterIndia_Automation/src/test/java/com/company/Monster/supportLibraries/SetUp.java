package com.company.Monster.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

public class SetUp {
	
	public static void initSetUp() throws IOException
	{
		getProperties();
		getCurrentClassName();
		getTestSuiteName();
		createFolds();
		ReportExcel.createReport();
	}
	
	public static void initSetupClasses()throws IOException
	{
		getProperties();
		getCurrentClassName();
		getTestSuiteName();
	}
	public static void getCurrentClassName()
	{
		StackTraceElement[] trace = Thread.currentThread().getStackTrace();
		//int i = trace.length - 1;
		Class<?> cls = null;
		    StackTraceElement ste = trace[3];
		    try {
		        cls = Class.forName(ste.getClassName());
		        //System.out.println("hey you: "+cls);
		        testVariables.currentClassName = cls.toString();
		        
		    } catch (ClassNotFoundException e) {
		    	System.out.println("the actual issue is in getCurrentClassName :"+e.getMessage());
		    } 		
	}
	
	public static void getTestSuiteName()
	{
		try
		{
			String strCurrentClassName = testVariables.currentClassName;
			//System.out.println("the current test class "+strCurrentClassName);
			strCurrentClassName = strCurrentClassName.replaceAll("class", "");
			strCurrentClassName = strCurrentClassName.trim();
			//System.out.println("the current test class "+strCurrentClassName);
			int lastIndexVal = strCurrentClassName.lastIndexOf('.');
			String strCurrentClassNamePath = strCurrentClassName.substring(0, lastIndexVal);
			strCurrentClassNamePath = strCurrentClassNamePath.replaceAll("\\.", "\\\\");
			String[] arrPath = strCurrentClassName.split("\\.");
			
			testVariables.currentTestSuite = strCurrentClassName.split("\\.")[arrPath.length-2];
			testVariables.executeClassName = strCurrentClassName.split("\\.")[arrPath.length-1];
			testVariables.currentTestCase = strCurrentClassName.split("\\.")[arrPath.length-1];
			testVariables.fileInput = testVariables.foldPath+"data\\"+testVariables.currentTestSuite+".xlsx";
			//System.out.println("Current TestSuite:"+testVariables.currentTestSuite);
			//System.out.println("Current TestCase:"+testVariables.currentTestCase);
			
		}
		catch(Exception e)
		{
			System.out.println("the actual issue is in getTestSuiteName :"+e.getMessage());
		}
	}
	
	public static void getProperties() throws IOException
	{
		/*
		Properties prop = new Properties();
		String propFileName = "config.properties";

		FileInputStream inputStream = new FileInputStream(new File(propFileName));

		prop.load(inputStream);
		testVariables.foldPath = prop.getProperty("path");
		*/
		String workingDir = System.getProperty("user.dir");
		testVariables.foldPath = workingDir+"\\";
	}

	public static void createFolds() throws UnknownHostException 
	{ 
		String classname = testVariables.currentTestCase;
		String foldName;
		String excelPath;
		String screenShot;
		String resPath = testVariables.resultPath;
		resPath = testVariables.foldPath+"Results"; 
		File f = new File(resPath); 
		if (f.exists() && f.isDirectory()) 
		{ } 
		else 
		{ 
			new File(resPath).mkdir(); 
		} 
		//Creating TC Folder 
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
		Calendar cal = Calendar.getInstance(); 
		String date = dateFormat.format(cal.getTime()); 
		foldName = classname+"_"+date.toString(); 
		foldName = foldName.replaceAll(" ", ""); 
		foldName = foldName.replaceAll(":", ""); 
		foldName = foldName.replaceAll("/", ""); 
		String tCFold = resPath+"\\"+foldName; 
		f = new File(tCFold); 
		if (f.exists() && f.isDirectory()) 
		{ } 
		else 
		{ 
			new File(tCFold).mkdir(); 
		}
		//Creating Excel folder 
		testVariables.excelPath = tCFold+"\\ExcelReport"; 
		excelPath = testVariables.excelPath;
		f = new File(excelPath); 
		if (f.exists() && f.isDirectory()) 
		{ } 
		else 
		{ 
			new File(excelPath).mkdir(); 
		}
		if(classname.toLowerCase().contains("healthcheck"))
			testVariables.fileOutput = excelPath+"\\healthCheck_"+CommonLibrary.getDate()+".xlsx";
		else
		{
			testVariables.fileOutput = excelPath+"\\"+classname+"_"+CommonLibrary.getDate()+".xlsx";
		}
		
		
		//Creating Screenshot folder
		testVariables.screenShotPath = tCFold+"\\ScreenShot"; 
		screenShot = testVariables.screenShotPath;
		f = new File(screenShot); 
		if (f.exists() && f.isDirectory()) 
		{ } 
		else 
		{ 
			new File(screenShot).mkdir(); 
		}
	}

	

}

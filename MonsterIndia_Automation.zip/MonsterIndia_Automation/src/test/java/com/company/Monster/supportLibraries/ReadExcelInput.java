package com.company.Monster.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelInput{

	static String fileInput;
	//static int intTestRw=1;

	@SuppressWarnings("resource")
	public static String readFromCell(String header) throws IOException 
	{ 
		String val = "";
		//System.out.println(header);
		try 
		{ 

			fileInput = testVariables.fileInput; 
			System.out.println("Input file: "+fileInput);
			int headCell = 0; 
			FileInputStream fis=new FileInputStream(new File(fileInput)); 
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet;
			//if(header.equals("Url")||header.equals("Browser")||header.equals("ToEmail")||header.equals("CCEmail")){
			if(header.equals("Url")||header.equals("Browser")||header.equals("ToEmail")||header.equals("CCEmail")||header.equals("OnFailureEMail")||header.equals("smsToEmail")||header.equals("ApplicationsList")||header.equals("ApplicationsListinCalManager")||header.equals("ApplicationsManagementListinSharedServices")||header.equals("ApplicationName")||header.equals("VSIIUrl")||header.equals("DBQuery")||header.equals("FRUrl")){

				sheet = wb.getSheet("MonsterIndiaInputData");

			}
			
			else if(header.equals("ApplicationNameinPlanningSystemView")||header.equals("CubeNameinPlanningSystemView")||header.equals("ApplicationNameinEssbaseSystemView")||header.equals("CubeNameinEssbaseSystemView")){

				sheet = wb.getSheet("NaukriInputData");

			}
			
			else if(header.equals("VZIDInUsersFilterField")||header.equals("GroupIDInGroupFilterField")){

				sheet = wb.getSheet("UserAndGroupDirectory");

			}
			
			else if(header.equals("FolderList")||header.equals("ReportName")){

				sheet = wb.getSheet("openDocumentOrPageInFile");

			}
			
			else if(header.equals("FolderNameToCreate")||header.equals("FolderNameToDelete")){

				sheet = wb.getSheet("Create_Delete_Folder");

			}
			
			else if(header.equals("FolderNameToCheckProvisionAccess")){

				sheet = wb.getSheet("Validate_Permissions");

			}
			
			else {

				sheet = wb.getSheet("input"); 

			}

			XSSFRow headRw = sheet.getRow(0); 
			int intCols = headRw.getLastCellNum(); 
			for(int i=0;i<intCols;i++) 
			{ 
				if(headRw.getCell(i).getStringCellValue().equalsIgnoreCase(header)) 
				{ 
					headCell = i; 
					break; 
				} 
			} 
			//System.out.println("head cell: "+headCell);
			int inttotRw = sheet.getLastRowNum(); 
			int intTestRw =0 ; 

			/*if(header.equals("Url")||header.equals("Browser")||header.equals("ToEmail")||header.equals("CCEmail")||header.equals("OnFailureEMail")||header.equals("smsToEmail")){
				intTestRw = 1;
			}
			else
			{*/
			for(int i=1;i<=inttotRw;i++) 
			{ 
				if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(testVariables.executeClassName)); 
				{
					intTestRw = i;
					break;
				} 
			} 
			//System.out.println("intTestRw cell: "+intTestRw);
			val = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
		} 

		catch (IOException e1) 
		{ // TODO Auto-generated catch block 
			System.out.println("File not found..IO Exception"+fileInput); 
		} 
		catch (Exception e) 
		{
			System.out.println("Either the cell is null or some unknown error occured in Reading the input file"); 
			System.out.println(e.getMessage()); 
			
			e.printStackTrace();
		} 
		return val; 
	} 


	@SuppressWarnings("resource")
	public static ArrayList<String> readFromCellForAllIteration(String header, String strDataProvider) throws IOException 
	{ 
		ArrayList<String> val = new ArrayList<String>();
		try 
		{ 

			fileInput = testVariables.fileInput; 
			//System.out.println("inside readfrom cell: "+fileInput);
			int headCell = 0; 
			FileInputStream fis=new FileInputStream(new File(fileInput)); 
			XSSFWorkbook wb = new XSSFWorkbook(fis); 
			XSSFSheet sheet = wb.getSheet("input"); 
			XSSFRow headRw = sheet.getRow(0); 
			int intCols = headRw.getLastCellNum(); 
			for(int i=0;i<intCols;i++) 
			{ 
				if(headRw.getCell(i).getStringCellValue().equalsIgnoreCase(header)) 
				{ 
					headCell = i; 
					break; 
				} 
			} 
			//System.out.println("head cell: "+headCell);
			int inttotRw = sheet.getLastRowNum(); 
			int intTestRw =0 ; 
			for(int i=1;i<=inttotRw;i++) 
			{ 
				//System.out.println(testVariables.currentTestCase);
				/*if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(testVariables.currentTestCase)) 
				{
					intTestRw = i;
					String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
					val.add(strVal);
					//System.out.println("intTestRw cell: "+strVal);

				} 
				if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(strDataProvider)) 
				{
					intTestRw = i;
					String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
					val.add(strVal);
					System.out.println("For HealthCheck row: "+i+strVal);

				}
				else if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(strDataProvider)) 
				{
					intTestRw = i;
					String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
					val.add(strVal);
					System.out.println("for HealthCheck1 row: "+i+strVal);
				}*/
				//String strTestcase = sheet.getRow(i).getCell(0).getStringCellValue();
				if(sheet.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(strDataProvider)) 
				{
					switch(strDataProvider){
					case "DRMUpdatingValues": 			
					{
						intTestRw = i;
						String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
						val.add(strVal);
						//System.out.println("For HealthCheck"+strVal);
						break;
					}
					/*case "HealthCheck1": 		
					{	
						intTestRw = i;
						String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
						val.add(strVal);
						//System.out.println("For HealthCheck1"+strVal);
						break;
					}
					case "HealthCheck2": 			
					{
						intTestRw = i;
						String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
						val.add(strVal);
						//System.out.println("For HealthCheck"+strVal);
						break;
					}
					case "HealthCheck3": 		
					{	
						intTestRw = i;
						String strVal = sheet.getRow(intTestRw).getCell(headCell).getStringCellValue(); 
						val.add(strVal);
						//System.out.println("For HealthCheck1"+strVal);
						break;
					}*/

					}
					//System.out.println("intTestRw cell in readFromCellForAllIteration: "+intTestRw);
				}
			} 
			//System.out.println("intTestRw cell: "+intTestRw);
		} 
		catch (IOException e1) 
		{ // TODO Auto-generated catch block 
			System.out.println("Input File not found..IO Exception"); 
		} 
		catch (Exception e) 
		{
			System.out.println("Either the cell is null or some unknown error occured in reading the Excel Input file"); 
			System.out.println(e.getMessage()); 
			val.add("");
		} 
		return val; 
	} 



}

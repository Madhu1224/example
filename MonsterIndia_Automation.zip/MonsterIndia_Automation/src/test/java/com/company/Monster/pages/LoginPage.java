package com.company.Monster.pages;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.CanPerformActionChain;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.Response;

import com.company.Monster.MonsterSupportLibraries.*;
import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.*;
import com.company.Monster.pages.*;
import com.company.Monster.supportLibraries.*;


public class LoginPage extends PageBase {

	public LoginPage(RemoteWebDriver driver, PageFactory pageFactory) {
		super(driver, pageFactory);

	}
	public static String strUsername;
	public static String strPassword;
	public static String strURL;
	public static String strURL1;
	public static String strBrowser;
	public static String strDateAndTime;
	public static String strNodeURL;
	DesiredCapabilities capabilities= new DesiredCapabilities();
	
	public LoginPage invokeBrowser() throws IOException, InterruptedException{
		//String domVal = FRVariables.domainVal;
		strURL = ReadExcelInput.readFromCell("Url");
		strBrowser = ReadExcelInput.readFromCell("Browser");
		strDateAndTime = CommonLibrary.getDateFull();
		//        System.out.println("the domain is :"+domVal);
		System.out.println(strBrowser);
		
		System.out.println(strURL);

		if (strBrowser.equalsIgnoreCase("FF")){
			strBrowser = "FireFox";
//			File file = new File(".\\drivers\\geckodriver.exe");
////		     
//		    System.setProperty("webdriver.gecko.driver",file.getAbsolutePath());			
			
			driver = new FirefoxDriver();
			//FRLib frLib = new FRLib(driver);
			/*	FirefoxBinary binary = new FirefoxBinary(new File("C:\\Users\\sivakma\\Downloads\\firefox-46.0.win64.sdk\\firefox-sdk\\bin\\firefox.exe"));
        	FirefoxProfile profile = new FirefoxProfile();
        	driver = new FirefoxDriver(binary, profile); */

		}
		else {
			File file = new File(".\\drivers\\IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
			
		}
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		new ScreenShotLib(driver);
		driver.manage().window().maximize();
		driver.get(strURL);
		Thread.sleep(3000);
		/*if(strURL.toLowerCase().contains("cpmbiuat"))
			Runtime.getRuntime().exec(".\\drivers\\CloseAuth.exe");;
*/
			return this;
	}
	
	public LoginPage closingChildWindow() {
		
		String winHandleBefore = driver.getWindowHandle();
		
		//Switch to new window opened
		for (String winHandle : driver.getWindowHandles()) {
		    driver.switchTo().window(winHandle);
		}

		// Perform the actions on new window
		driver.close(); //this will close new opened window

		//switch back to main window using this code
		driver.switchTo().window(winHandleBefore);

		return this;
		
    }

	
	public LoginPage RecruiterLogin() throws Exception{
		
		clickOnEle("xpath", ".//a[text()='Employers ']");
		
//		clickOnEle("linktext", "Login here");
		
		clickOnEle("xpath", ".//li[text()='Login here']");		
		
		return this;
	}
	public LoginPage enterUserName(String strUsername) throws Exception{
		
		invokeWebDriverWait(120, "visibilityofelementlocated", "name","login");
		
		clickOnEle("name", "login");
		clearText("name", "login");
		setValue("name", "login", strUsername);
		return this;
	}

	public LoginPage enterPassword(String strPassword) throws Exception{
		setValue("name", "passwd", strPassword);
		return this;
	}	


	public HomePage clickSignOn() throws Exception{
		clickOnEle("name","sub_but1");
		return new PageFactory(driver).homePage();
	}
	
	
}

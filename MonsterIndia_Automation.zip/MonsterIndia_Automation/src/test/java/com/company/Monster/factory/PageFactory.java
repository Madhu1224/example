package com.company.Monster.factory;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.company.Monster.MonsterSupportLibraries.*;
import com.company.Monster.objectRepository.*;
import com.company.Monster.pages.*;
import com.company.Monster.supportLibraries.*;


public class PageFactory {

	private RemoteWebDriver driver;

	public PageFactory(RemoteWebDriver driver){
		this.driver = driver;
	}

	public PageFactory() {
		// TODO Auto-generated constructor stub
	}

	public LoginPage loginPage(){
		return new LoginPage(driver,this);
	}

	public HomePage homePage(){
		return new HomePage(driver,this);
	}
	
		
	public String takeScreenshotAndSave()
	{
		String screenshotName = "";
		try
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Calendar cal = Calendar.getInstance();
			String date = dateFormat.format(cal.getTime());
			String snapTime = date.toString();
			snapTime = snapTime.replaceAll(" ", "");
			snapTime = snapTime.replaceAll(":", "");
			snapTime = snapTime.replaceAll("/", "");
			//System.out.println("just above line");
			//System.out.println("the title is :"+driver.getTitle());
			File screenShotSrcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			//System.out.println("just afer line");
			screenshotName = testVariables.screenShotPath+"\\_"+testVariables.currentTestCase+"_"+snapTime+".png";
			//System.out.println("teh variable :"+screenshotName);
			FileUtils.copyFile(screenShotSrcFile, new File(screenshotName));
			//System.out.println("just afer cpoy line");
		}
		catch(Exception e)
		{
			System.out.println("the exception is :"+e.getMessage());
			//ReportExcel.addstep("Unable to take screenshot", "Fail");
		}
		return screenshotName;
	}

}

package com.company.Monster.pages;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.company.Monster.MonsterSupportLibraries.*;
import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.*;
import com.company.Monster.pages.*;
import com.company.Monster.supportLibraries.*;



public class PageBase {

	protected RemoteWebDriver driver;
	protected PageFactory pageFactory;

	//public WSLib obieeLib;
	public CommonLibrary commonLibrary;

	public PageBase(){
	}

	public PageBase(RemoteWebDriver driver,PageFactory pageFactory){
		this.driver=driver;
		this.pageFactory=pageFactory;
		//obieeLib = new WSLib(driver);


		commonLibrary = new CommonLibrary();
	}

	public PageFactory getPageFactory(){
		return pageFactory;	
	}

	public boolean existsOrNot(String loc, String locVal) throws Exception
	{

		boolean blnExist = false;
		
		try{
			
		By by = locBy(loc, locVal);
		blnExist = driver.findElement(by).isDisplayed();
		
		}
		
		catch(Exception e){
			
			
		}
		return blnExist;
	}


	//@SuppressWarnings("finally")
	public By locBy(String loc, String locVal)
	{
		By by = null;
		/*try
		{*/
		switch(loc.toUpperCase()){

		case "ID": 			by = By.id(locVal);
		break;
		case "XPATH": 		by = By.xpath(locVal);
		break;	
		case "LINKTEXT":	by = By.linkText(locVal);
		break;
		case "CSSSELECTOR": by = By.cssSelector(locVal);
		break;
		case "CLASSNAME":	by = By.className(locVal);
		break;
		case "TAGNAME":		by = By.tagName(locVal);
		break;
		case "NAME":		by = By.name(locVal);
		break;

		}/*
		}
		catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			System.out.println("locBy element not found part: "+e.getMessage());
			ReportExcel.addstep("Element not found", "Fail", "validatePandLDashBoard");
		}
		catch (WebDriverException e) {
			// TODO Auto-generated catch block
			System.out.println("locBy Driver is being closed part: "+e.getMessage());
			ReportExcel.addstep("Driver is being closed", "Fail", "validatePandLDashBoard");
		}catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("locBy Unkmown exception thrown part: "+e.getMessage());
			ReportExcel.addstep("Unkmown exception thrown", "Fail", "validatePandLDashBoard");
		}	
		finally
		{*/
		return by;
		//}
	}

	@SuppressWarnings("finally")
	public WebElement createWebElement(String loc, String locVal) throws Exception
	{
		WebElement ele = null;
		try
		{
			By by = locBy(loc, locVal);
			ele = driver.findElement(by);
		}
		catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			System.out.println("Element not found..with following message: "+e.getMessage());
			//ReportExcel.addstep("Element not found for the Locator: "+loc+" and Locator Value: "+locVal," ", "Fail", testVariables.currentTestCase);
			//System.out.println("should throw an exception inside createWebElement:"+locVal);
			throw new Exception("NoElementOnAppException");
		}
		catch (WebDriverException e) {
			// TODO Auto-generated catch block
			//ReportExcel.addstep("Driver is being closed..with folowing message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Driver is being closed..with following message: "+e.getMessage());
			throw new Exception("NoElementOnAppException");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block

			//ReportExcel.addstep("Unkmown exception thrown..with foloowing message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Unkmown exception thrown..with following message: "+e.getMessage());
			throw new Exception("NoElementOnAppException");
		}
		finally
		{
			return ele;
		}
	}

	@SuppressWarnings("finally")
	public WebElement createWebElement(WebElement ele, String loc, String locVal)
	{
		WebElement elem = null;
		try
		{
			By by = locBy(loc, locVal);
			elem = ele.findElement(by);
			//elem = driver.findElement(by);
		}
		catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			System.out.println("Element not found..with following message: "+e.getMessage());
			ReportExcel.addstep("Element not found for the Locator: "+loc+" and Locator Value: "+locVal," ", "Fail", testVariables.currentTestCase);
		}
		catch (WebDriverException e) {
			// TODO Auto-generated catch block
			ReportExcel.addstep("Driver is being closed..with following message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Driver is being closed..with following message: "+e.getMessage());
		}catch (Exception e) {
			// TODO Auto-generated catch block
			ReportExcel.addstep("Unkmown exception thrown..with following message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Unkmown exception thrown..with following message: "+e.getMessage());
		}
		finally
		{
			return elem;
		}
	}

	@SuppressWarnings("finally")
	public List<WebElement> createWebElements(WebElement ele,String loc, String locVal) throws Exception
	{

		List<WebElement> eles = null;
		try
		{
			By by = locBy(loc, locVal);
			eles = ele.findElements(by);
		}
		catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			System.out.println("Element not found..with following message: "+e.getMessage());
			ReportExcel.addstep("Element not found for the Locator: "+loc+" and Locator Value: "+locVal," ", "Fail", testVariables.currentTestCase);
			throw new Exception("NoElementOnAppException");
		}
		catch (WebDriverException e) {
			// TODO Auto-generated catch block
			ReportExcel.addstep("Driver is being closed..with following message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Driver is being closed..with following message: "+e.getMessage());
			throw new Exception("NoElementOnAppException");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block

			ReportExcel.addstep("Unknown exception thrown..with following message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Unknown exception thrown..with following message: "+e.getMessage());
			throw new Exception("NoElementOnAppException");
		}
		finally
		{
			return eles;
		}
	}
	
	public void waitTime(String loc,String locVal) throws Exception{
		
	for(int i=0;i<120;i++)
	{
		WebElement ele =createWebElement(loc,locVal);
		if(ele.isDisplayed())
		{
			Thread.sleep(1000);
		}
		else
		{
			break;
		}
	}
	
	}
	public List<WebElement> createWebElements(String loc, String locVal) throws Exception
	{

		List<WebElement> eles = null;
		try
		{
			By by = locBy(loc, locVal);
			eles = driver.findElements(by);
		}
		catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			System.out.println("Element not found..with following message: "+e.getMessage());
			ReportExcel.addstep("Element not found for the Locator: "+loc+" and Locator Value: "+locVal," ", "Fail", testVariables.currentTestCase);
			throw new Exception("NoElementOnAppException");
		}
		catch (WebDriverException e) {
			// TODO Auto-generated catch block
			ReportExcel.addstep("Driver is being closed..with following message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Driver is being closed..with following message: "+e.getMessage());
			throw new Exception("NoElementOnAppException");
		}
		catch (Exception e) {
			// TODO Auto-generated catch block

			ReportExcel.addstep("Unkmown exception thrown..with following message: "+e.getMessage()," ", "Fail", testVariables.currentTestCase);
			System.out.println("Unkmown exception thrown..with following message: "+e.getMessage());
			throw new Exception("NoElementOnAppException");
		}
		finally
		{
			return eles;
		}
	}

	public void clickOnEle(String loc, String locVal) throws Exception
	{
		WebElement ele = createWebElement(loc, locVal);
		ele.click();
	}
	
	public void clickOnEle(WebElement ele) throws Exception
	{
		//WebElement ele = createWebElement(loc, locVal);
		ele.click();
	}

	public WebElement getWebEle(String loc, String locVal) throws Exception
	{
		WebElement ele = createWebElement(loc, locVal);
		return ele;
	}

	public void hoverOverToElement(String loc, String locVal) throws Exception
	{
		
		WebElement ele = createWebElement(loc, locVal);
	Actions builder = new Actions(driver);

	 
	 builder.moveToElement(ele).build().perform();;
}

	public void selectDropDown(String loc, String locVal,String selectValue) throws Exception

	{
		WebElement ele = createWebElement(loc, locVal);

		Select oSelect = new Select(ele);

		oSelect.selectByValue(selectValue);


	}


	public void switchToFrame(String loc, String locVal) throws Exception
	{
		WebElement eleFrame = createWebElement(loc, locVal);
		driver.switchTo().frame(eleFrame);
	}


	public void switchToDefault()
	{
		driver.switchTo().defaultContent();
	}
	
	public void switchToFrameNumber(int i)
	
	{
		driver.switchTo().frame(i);
	}

	public void switchToFrameById(String frameID) throws Exception
	{
		//WebElement eleFrame = createWebElement(loc, locVal);
		driver.switchTo().frame(frameID);
	}


	public void switchToFrameByNum(int frameNum) throws Exception
	{
		
		driver.switchTo().frame(frameNum);
	}





	public void clickOnEle(WebElement ele,String loc, String locVal) throws Exception
	{
		List<WebElement> ele1 = createWebElements(loc, locVal);
		for(int i=0;i<ele1.size();i++)
		{
			ele1 = createWebElements(loc, locVal);

			ele=ele1.get(i);

			ele.click();

		}


	}

	public void clearText(String loc, String locVal) throws Exception

	{
		WebElement ele = createWebElement(loc, locVal);
		ele.clear();
	}

	public void clickOnEleJS(String loc, String locVal) throws Exception
	{
		WebElement ele = createWebElement(loc, locVal);
		String js = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';arguments[0].click();";
		((JavascriptExecutor) driver).executeScript(js, ele);
	}
	
	public void clickOnEleJS(WebElement ele) throws Exception
	{
		//WebElement ele = createWebElement(loc, locVal);
		String js = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';arguments[0].click();";
		((JavascriptExecutor) driver).executeScript(js, ele);
	}

	
	
	public void scrollDownToElement() throws InterruptedException {
      /*  ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView();", element);*/
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		//jse.executeScript("window.scrollBy(0,250)", "");
		
		jse.executeScript("scroll(0, 250);");
		
		/*((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500);*/
    }

	public void pageDownUsingKeys() throws Exception {
	   
	 
	    //driver.navigate().to("http://www.alexa.com/topsites/countries;15/LU");
	 
	   /* Actions action = new Actions(driver);
	    action.sendKeys(Keys.PAGE_DOWN);
	    Thread.sleep(2000);*/
		
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_PAGE_DOWN);
		robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
//	    action.click(ele).perform();
	}
	
	
	
	
	public void clickOn()
	{
		WebElement ele = driver.findElement(By.xpath("//td[contains(@class,'obipsTabBarToolbarCell')]/img"));
		ele.click();
	}


	public void doubleClick(WebElement ele) throws Exception{

		Actions act=new Actions(driver);

		//WebElement ele = createWebElement(loc, locVal);
		act.doubleClick(ele).build().perform();			

	}
	
	public void doubleClickOn(String loc,String locVal) throws Exception{

		Actions act=new Actions(driver);

		WebElement ele = createWebElement(loc, locVal);
		act.doubleClick(ele).build().perform();			

	}

	public void hoverOver(String loc,String locval) throws Exception{

		Actions act=new Actions(driver);

		WebElement ele=getWebEle(loc, locval);

		act.moveToElement(ele).build().perform();		


	}

	public void delete(String loc,String locVal) throws Exception{

		WebElement del = createWebElement(loc, locVal);

		del.sendKeys(Keys.DELETE);

	}

	public void enter(String loc,String locVal) throws Exception{

		WebElement enter = createWebElement(loc, locVal);

		enter.sendKeys(Keys.ENTER);

	}

	public void setValue(String loc, String locVal,String value) throws Exception
	{
		WebElement ele = createWebElement(loc, locVal);
		ele.sendKeys(value);
	}

	public void invokeWebDriverWait(int intTimeToWait, String strExpectedCondition, String loc, String locVal) throws Exception
	{
		WebDriverWait wait = new WebDriverWait(driver,intTimeToWait);
		if(strExpectedCondition.toLowerCase().equals("alertispresent"))
			wait.until(ExpectedConditions.alertIsPresent());
		else if(strExpectedCondition.toLowerCase().equals("visibilityofelementlocated"))
		{
			By by = locBy(loc, locVal);
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		}

	}
	
	public void invokeWebDriverWaitTextToBePresent(int intTimeToWait, String strExpectedCondition, String loc, String locVal,String eleText) throws Exception
	{
		WebDriverWait wait = new WebDriverWait(driver,intTimeToWait);

		if(strExpectedCondition.toLowerCase().equals("textToBePresentInElement"))
		{
			By by = locBy(loc, locVal);
			WebElement ele=createWebElement(loc, locVal);
			//eleText=ele.getText();
			wait.until(ExpectedConditions.textToBePresentInElement(ele, eleText));

		}

	}

	public boolean isDisplayed(String loc, String locVal) throws Exception
	{

		boolean status=false;
		WebElement ele = createWebElement(loc, locVal);
		if(ele.isDisplayed()){

			status=true;

		}

		return status;
	}
	
	public boolean isDisplayed(WebElement ele) throws Exception
	{

		boolean status=false;
		//WebElement ele = createWebElement(loc, locVal);
		if(ele.isDisplayed()){

			status=true;

		}

		return status;
	}

	public boolean isEnabled(String loc, String locVal) throws Exception
	{

		boolean status=false;
		WebElement ele = createWebElement(loc, locVal);
		if(ele.isEnabled()){

			status=true;

		}

		return status;
	}

	public boolean isEnabled(WebElement ele) throws Exception
	{

		boolean status=false;
		
		if(ele.isEnabled()){

			status=true;

		}

		return status;
	}
	public String pageSource() throws Exception
	{
		String pageSource=null;
		pageSource=driver.getPageSource();
		return pageSource;
	}

	public int switchingWindows() throws Exception
	{
		int count=0;

		count= driver.getWindowHandles().size();

		return count;
	}
	/*public void clickOnExpand() throws Exception
	{
		clickOnEle("xpath", ".//img[@class='dxtl__Expand']");

	}*/

	public void reload() throws Exception
	{
		//driver.navigate().refresh();
		driver.executeScript("location.reload()"); 

	}
	
	public void refresh() throws Exception
	
	{
		driver.navigate().refresh();
		 

	}
	
	public String getClassName(String strClassName)
	{
		String strName;
		System.out.println(strClassName);
		String[] arrClassName = strClassName.split("\\.");
		strName = arrClassName[1];
		System.out.println(strName);
		return strName;
	}

	public void waitForPgLoad() {
		try
		{
			ExpectedCondition<Boolean> pageLoadCondition = new
					ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
				}
			};
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(pageLoadCondition);
		}
		catch(TimeoutException e)
		{
			System.out.println("wait for page load thing: "+e.getMessage());
			waitForPgLoad();
		}
	}

	public void ajaxWait(int maxWaitTime) throws InterruptedException {

		try

		{	

			for (int i = 0 ; i < maxWaitTime; i++) {
				String ajaxComplete = ((JavascriptExecutor)driver).executeScript("return jQuery.active == 0").toString();				   
				System.out.println("ajaxComplete=" + ajaxComplete + " countdown seconds..= " + (maxWaitTime - i));
				if (ajaxComplete.equalsIgnoreCase("true")) {
					break;
				}
				Thread.sleep(4000);
			}
		}
		catch(TimeoutException e)
		{
			System.out.println("wait for page load thing: "+e.getMessage());
			//waitForPgLoad();
		}
	}
	public String getTitleOfPage()
	{
		String strName;
		strName = driver.getTitle();
		return strName;
	}
	
	public Set<String> getWindows()
	{
		Set<String> windowHandles;
		windowHandles = driver.getWindowHandles();
		return windowHandles;
	}


	public String getTextValue(String loc, String locVal,String attValue) throws Exception
	{
		String strText;

		WebElement ele = createWebElement(loc, locVal);		
		strText=ele.getAttribute(attValue);	

		return strText;
	}

	public String getText(String loc, String locVal) throws Exception
	{
		String strText;

		WebElement ele = createWebElement(loc, locVal);		
		strText=ele.getText();

		return strText;
	}


	public String getPageContent(){
		String pageValue;

		WebElement pgValue =driver.findElement(By.tagName("body"));

		pageValue=pgValue.getText();
		//System.out.println("pagevalue is "+pgValue.getText());
		return pageValue;

	}
	public void rightClick(String loc,String locVal) throws Exception{

		Actions oAction = new Actions(driver);
		WebElement ele;
		try {
			ele = createWebElement(loc, locVal);

			oAction.moveToElement(ele);
			oAction.contextClick(ele).build().perform();  /* this will perform right click */

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void rightClick(WebElement ele) throws Exception{

		Actions act=new Actions(driver);

		//WebElement ele = createWebElement(loc, locVal);
		act.contextClick(ele).build().perform(); 			

	}	
	
	public void KeyBoardActions(String letter) throws Exception{
		
		try {
	
		Actions action = new Actions(driver);
	
		action.keyDown(Keys.CONTROL).sendKeys(letter).keyUp(Keys.CONTROL).perform();	
	
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();

		}
		
	}
	
	public void escape() throws Exception{

		Actions action = new Actions(driver);
		
		try {
	
			action.sendKeys(Keys.ESCAPE); /* this will perform escape click */

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void closeAll(){
		driver.quit();
	}


}

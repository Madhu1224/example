package com.company.Monster.supportLibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Properties;

import javax.xml.bind.DatatypeConverter;

import com.company.Monster.MonsterSupportLibraries.*;
import com.company.Monster.objectRepository.*;
import com.company.Monster.pages.*;
import com.company.Monster.supportLibraries.*;


public class CommonLibrary {


	
	
	public String removeCharacter(String strVal, String character)
	{
		String result = "";
		if(strVal.contains(character))
			result = strVal.replaceAll(character, "");
		
		
		return result;
	}
	
	public String removeCharacters(String strVal)
	{
		String result = strVal;
		if(strVal.contains(" bps") || strVal.contains("%") || strVal.contains("x") )
		{
			result = strVal.replaceAll(" bps", "");
			if(result.contains("%"))
			{
				result = result.replaceAll("%", "");
				//result = Integer.toString(noDecimals(result));
			}
			if(result.contains("x"))
			{
				result = result.replaceAll("x", "");
				//result = Integer.toString(noDecimals(result));
			}
			if(result.contains("("))
			{
				result = result.replaceAll("\\(", "");
				result = result.replaceAll("\\)", "");
				result = "-"+result;
			}
		}
		
		if(result.equals("0.0"))
			result = "0";
		return result;
	}
	
	public static String convertToRightFormat(String strVal) throws ParseException
	{
		NumberFormat format = NumberFormat.getCurrencyInstance();
		Number number = format.parse(strVal);
		String val = number.toString();
		if(val.equals("-0.0"))
			val = "0";
		return val;
	}
	
    public static double roundTwoDecimals(double input) {
    	//double input = Double.parseDouble(amount);
    	double newKB = Math.round(input*100.0)/100.0;
		return newKB;
    }
    
    public static int noDecimals(String string) {
    	double input = Double.parseDouble(string);
    	double newKB = Math.round(input * 100) / 100;
    	int Val = (int) newKB;
		return Val;
    }
    public static String getDateFull()
    {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
		Calendar cal = Calendar.getInstance(); 
		String date = dateFormat.format(cal.getTime()); 
		String dateToReturn = date.toString();
		return dateToReturn;
    }
    public static String getDate()
    {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
		Calendar cal = Calendar.getInstance(); 
		String date = dateFormat.format(cal.getTime()); 
		String dateToReturn = date.toString();
		dateToReturn = dateToReturn.replaceAll(" ", "_"); 
		dateToReturn = dateToReturn.replaceAll(":", ""); 
		dateToReturn = dateToReturn.replaceAll("/", ""); 
		return dateToReturn;
    }
    
	public static String convertSecondsToHMmSs(long seconds) {
	    long s = (seconds/1000) % 60;
	    long m = ((seconds/1000) / 60) % 60;
	    long h = ((seconds/1000) / (60 * 60)) % 24;
	    return String.format("%d:%02d:%02d", h,m,s);
	}
	public String getUserName() throws IOException
	{
		Properties prop = new Properties();
		String propFileName = "credentials.properties";

		FileInputStream inputStream = new FileInputStream(new File(propFileName));

		prop.load(inputStream);
		String strUserName = prop.getProperty("Username");
		return strUserName;

	}

	public String getPassword() throws IOException
	{
		Properties prop = new Properties();
		String propFileName = "credentials.properties";

		FileInputStream inputStream = new FileInputStream(new File(propFileName));

		prop.load(inputStream);
		String strPassword = prop.getProperty("Password");
		strPassword = new String(DatatypeConverter.parseBase64Binary(strPassword));
		return strPassword;

	}

}

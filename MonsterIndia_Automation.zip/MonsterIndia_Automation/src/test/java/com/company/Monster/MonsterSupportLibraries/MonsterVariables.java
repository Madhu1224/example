package com.company.Monster.MonsterSupportLibraries;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

public class MonsterVariables {
	   //public static Hashtable<String,ArrayList<ArrayList<String>>> lstExcelTable = new Hashtable<String,ArrayList<ArrayList<String>>>();
	   //public static Hashtable<String,ArrayList<ArrayList<String>>> lstdashBTable = new Hashtable<String,ArrayList<ArrayList<String>>>();
	public static Hashtable<String,ArrayList<ArrayList<String>>> commonTableALOfALOfString= new Hashtable<String,ArrayList<ArrayList<String>>>();
	public static Hashtable<String,Hashtable<String,Integer>> commonTableRwColMap= new Hashtable<String,Hashtable<String,Integer>>();
	public static Hashtable<String,ArrayList<String>> reportTable= new Hashtable<String,ArrayList<String>>();
	public static Object[][] allList= null;
	public static Hashtable<String,String> consolidatedEmail= null;
	public static Hashtable reportDetailsNew = new <String>Hashtable();   
	public static Hashtable<String,String> consolidatedStatus = null;
	public static Hashtable<String,String> consolidatedStatusSorted = null;
	public static int totalReportCount;
	public static int warnCount=0;
	public static int failCount=0;
	public static int passCount=0;
	public static Hashtable<String,String> consolidatedFailStatus = null;
	public static boolean blnLoginStatus;
	public static Vector <String> failedReportsVector=new Vector<String>();
	
	
	
}

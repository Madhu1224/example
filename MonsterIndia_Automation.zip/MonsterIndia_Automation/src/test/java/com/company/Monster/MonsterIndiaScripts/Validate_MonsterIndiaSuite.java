package com.company.Monster.MonsterIndiaScripts;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.ObjRepo;
import com.company.Monster.pages.HomePage;
import com.company.Monster.pages.LoginPage;
import com.company.Monster.supportLibraries.CommonLibrary;
import com.company.Monster.supportLibraries.ReadExcelInput;
import com.company.Monster.supportLibraries.ReportExcel;
import com.company.Monster.supportLibraries.ScreenShotLib;
import com.company.Monster.supportLibraries.SetUp;
import com.company.Monster.supportLibraries.testVariables;
//import com.company.monster.factory.PageFactory;

public class Validate_MonsterIndiaSuite {


	protected static RemoteWebDriver driver;
	static LoginPage loginPg;
	static HomePage homePg;


	static CommonLibrary commonLibrary;

	public PageFactory getPageFactory(){
		return new PageFactory(driver);       

	}


	@BeforeClass(groups = { "Regression" })
	public void initialSetUp() throws IOException, MalformedURLException, Exception
	{

		SetUp.initSetUp();		

		commonLibrary= new CommonLibrary();

		//String strURL = ReadExcelInput.readFromCell("Url");
		
		//String strBrowser = ReadExcelInput.readFromCell("Browser");

		String strUsername = commonLibrary.getUserName();

		String strPassword = commonLibrary.getPassword();

		try{

			loginPg = new LoginPage(driver, getPageFactory());// pageFact.loginPage();

			//loginPg.invokeBrowser(strURL,strBrowser);
			loginPg.invokeBrowser();

			Thread.sleep(5000);
			
			loginPg.closingChildWindow();
			
			System.out.println("closing the child window");

			//loginPg.switchToFrame("tagname", "frame");
			
			loginPg.RecruiterLogin();

			loginPg.enterUserName(strUsername);

			loginPg.enterPassword(strPassword);

			Thread.sleep(3000);

			homePg = loginPg.clickSignOn();

			Thread.sleep(5000);

			homePg.existsOrNot("id", ObjRepo.HomePage_Home_id);										

			ReportExcel.addstep("HFM WorkSpace-Login Validation ","User is able to see the home page", "Login Successfull", "Pass");


		}
		catch(Exception e)
		{
			e.printStackTrace();

			//loginPg.closeAll();

			ReportExcel.addstep("HFM WorkSpace-Login Validation ","User is able to see the home page", "Login Failed", "Fail");
			
			ScreenShotLib.takeScreenshotAndSave("initialSetUp");

			throw new Exception("LoginFailed");
		}


	}

	@Test(priority=1,enabled=true)
		
		public void validateApplicationsInConsolidationAdministration() throws Exception

		{
			try {
				
				Thread.sleep(7000);

				homePg.clickOnNavigate();
				
				Thread.sleep(3000);
				
				homePg.clickOnAdminister();
				
				Thread.sleep(3000);
				
				homePg.clickOnConsolidationAdministration();
				
				Thread.sleep(3000);				
		
				homePg.clickOnApplicationsInAdminTasks();
				
				homePg.clickOnApplicationName();
				
			}

			catch(Exception e){

				System.out.println(e.getMessage());

				e.printStackTrace();
				
				ScreenShotLib.takeScreenshotAndSave("openAnApplicationInConsolidationAdministration");
			
				ReportExcel.addstep("HFM Application - HealthCheck : Validating Health check of Application Names in Consolidation Administration ","User is able to open the Required Applciation Successfully in Consolidation Administration.","The required scenario is not validated successfully. Beacause of the following issue: "+e.getMessage(),"Fail");				
				
				//ScreenShotLib.takeScreenshotAndSave("openAnApplicationInConsolidationAdministration");
			}

		}


	@AfterClass(groups = { "Regression" })

	public void afterExecution() throws IOException

	{

		String toEmail = ReadExcelInput.readFromCell("ToEmail");
		String ccEmail = ReadExcelInput.readFromCell("CCEmail");
		String onFailureEMail = ReadExcelInput.readFromCell("OnFailureEMail");
		//String smsToEmail = ReadExcelInput.readFromCell("smsToEmail");
		
		loginPg.closeAll();

		System.out.println("Closing the browser");
		
		//Email.send(toEmail, ccEmail," EPM HFM Workspace - Status Report","Please find the attached to check the status of HFM Tests Run",testVariables.fileOutput);
	}
}
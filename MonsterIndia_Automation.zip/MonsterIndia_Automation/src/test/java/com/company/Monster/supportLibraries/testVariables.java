package com.company.Monster.supportLibraries;

import java.util.ArrayList;

public class testVariables {

	public static String currentTestCase;
	public static String currentTestSuite;
	public static String currentClassName;
	public static String currentDataSheetName;
	public static String foldPath;
	public static String fileInput;
	public static String fileOutput;
	public static String excelPath;
	public static String resultPath;
	public static String screenShotPath;
	public static String executeClassName;
	
	//public static ArrayList<String>appnMenuOptions;

	//public static ArrayList<String>appnMenuOptionsInput;
	//public static Long executionTime = (long) 0.000;
	//public static Long totalTime;
	
}

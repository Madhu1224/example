package com.company.Monster.pages;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
//import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.poi.ddf.EscherColorRef.SysIndexProcedure;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.company.Monster.MonsterSupportLibraries.*;
import com.company.Monster.factory.PageFactory;
import com.company.Monster.objectRepository.*;
import com.company.Monster.supportLibraries.*;


public class HomePage extends PageBase{
	public static String strDashBoard;
	public static String strReport;
	//public OBIEELib obieeLib;
	public HomePage(RemoteWebDriver driver, PageFactory pageFactory){
		super(driver, pageFactory);
		//obieeLib = new OBIEELib();
	}

	
	
	 /*public  void closingChildWindow(String loc,String locVal) {
	        try {

	            WebElement ele=createWebElement(loc,locVal);

	            //WebElement windowpopup = driver.findElement(By.xpath(locator));
	            JavascriptExecutor executor = (JavascriptExecutor) driver;
	            executor.executeScript("arguments[0].click();", ele);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	*/
	
	public HomePage closingChildWindow() {
		
		String winHandleBefore = driver.getWindowHandle();
		
		//Switch to new window opened
		for (String winHandle : driver.getWindowHandles()) {
		    driver.switchTo().window(winHandle);
		}

		// Perform the actions on new window
		driver.close(); //this will close new opened window

		//switch back to main window using this code
		driver.switchTo().window(winHandleBefore);

		return this;
		
    }

	
	

	public HomePage handleAlert(String strAction) throws Exception
	{
		invokeWebDriverWait(150, "alertispresent", "", "");
		Alert alert=driver.switchTo().alert();
		if(strAction.toLowerCase().equals("accept"))
			alert.accept();
		else if(strAction.toLowerCase().equals("dismiss"))
			alert.dismiss();

		return this;

	}

	public HomePage clickOnNavigate() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_Navigate_xpath);

		System.out.println("clicked on Navigation");

		return this;

	}

	public HomePage clickOnApplication() throws Exception

	{		
		clickOnEle("xpath", ObjRepo.HomePage_Application_xpath);

		System.out.println("clicked on Application");

		return this;

	}

	public HomePage clickOnPlanning() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_Planning_xpath);

		System.out.println("clicked on Planning");

		return this;

	}

	public HomePage getTheAppName() throws Exception

	{
		ArrayList<String> appNamesList=new ArrayList<String>();

		ArrayList<String>appNamesListInput=new ArrayList<String>();

		ArrayList<String> differentAppList= new ArrayList<String>();

		String inputAppNames=ReadExcelInput.readFromCell("ApplicationsList");

		String[] appNames=inputAppNames.split(";");

		for(int k=0;k<appNames.length;k++){

			appNamesListInput.add(appNames[k]);

		}

		List<WebElement>lstAppRows=createWebElements("tagname", "table");

		List<WebElement>lstApp=createWebElements(lstAppRows.get(2),"tagname", "tr");

		for(int i=1;i<lstApp.size();i++){

			lstApp=createWebElements(lstAppRows.get(2),"tagname", "tr");

			System.out.println("app name is: "+lstApp.get(i).getText());

			String trimApp=lstApp.get(i).getText();

			trimApp=trimApp.trim();			

			appNamesList.add(trimApp);

		}

		for (String s : appNamesListInput) {
			if (!appNamesList.contains(s)) {
				differentAppList.add(s);
			}
		}

		if(!differentAppList.isEmpty()){

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Application Names in Planning ","User is able to see the following Applciations: "+appNamesListInput+" Successfully in Planning.","Applciations: "+appNamesList+" are shown successfully. But "+differentAppList+" are not shown in Planning.","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateApplicationsListInPlanning");

		}
		else{

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Application Names in Planning ","User is able to see the following Options: "+appNamesListInput+" Successfully in Planning.","Applciations: "+appNamesList+"are shown successfully.","Pass");
		}

		clickOnEle("xpath", ObjRepo.HomePage_BodySPace_xpath);

		return this;
	}


	public HomePage clickingEscape() throws Exception{

		escape();

		System.out.println("Clicked on Escape");

		return this;
	}

	public HomePage clickOnAdminister() throws Exception

	{		
		clickOnEle("xpath", ObjRepo.HomePage_Administer_xpath);

		System.out.println("clicked on Administer");

		return this;

	}

	public HomePage clickOnCalculationManager() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_CalcManager_xpath);

		System.out.println("clicked on calculation manager");

		return this;

	}

	public HomePage getTheSystemViewNamesLists() throws Exception{


		ArrayList<String> appNamesList=new ArrayList<String>();


		ArrayList<String>appNamesListInput=new ArrayList<String>();

		ArrayList<String> diffSysViewApps= new ArrayList<String>();

		String inputAppNames=ReadExcelInput.readFromCell("ApplicationsListinCalManager");

		String[] appNames=inputAppNames.split(";");

		for(int k=0;k<appNames.length;k++){

			appNamesListInput.add(appNames[k]);

		}

		invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_SelectView_xpath);

		WebElement mainTable=createWebElement("xpath",ObjRepo.HomePage_CalcManagerSystemView_xpath);

		List<WebElement>allRows=createWebElements(mainTable,"tagname","tr");

		for(int i=0;i<allRows.size();i++){

			allRows=createWebElements(mainTable,"tagname","tr");

			List<WebElement> allValues=createWebElements(allRows.get(i),"tagname","td");

			System.out.println("column value "+allValues.get(0).getText());

			appNamesList.add(allValues.get(0).getText());

		}


		for (String s : appNamesListInput) {
			if (!appNamesList.contains(s)) {
				diffSysViewApps.add(s);
			}
		}

		if(!diffSysViewApps.isEmpty()){

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Application Names in Calculation Manager","User is able to see the following Applciations: "+appNamesListInput+" Successfully in Calculation Manager.","Applcations: "+appNamesList+" are shown successfully. But "+diffSysViewApps+" are not shown in  Calculation Manager.","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerApplicationsList");

		}
		else{

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Application Names in Calculation Manager","User is able to see the following Options: "+appNamesListInput+" Successfully in Calculation Manager.","Applcations: "+appNamesList+"are shown successfully.","Pass");
		}

		return this;
	}


	public HomePage clickOnClose() throws Exception

	{		
		switchToDefault();

		switchToFrame("tagname", "frame");

		clickOnEle("xpath", ObjRepo.HomePage_ClosingApplciation_xpath);

		System.out.println("clicked on closing calc manager");

		return this;

	}

	public HomePage clickOnSharedServices() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_SharedServices_xpath);

		System.out.println("clicked on shared services");

		return this;

	}

	public HomePage getTheSharedServicesApplicationManagementList() throws Exception{


		ArrayList<String> appNamesList=new ArrayList<String>();

		ArrayList<String>appNamesListInput=new ArrayList<String>();

		ArrayList<String> diffSysViewApps= new ArrayList<String>();

		String inputAppNames=ReadExcelInput.readFromCell("ApplicationsManagementListinSharedServices");

		String[] appNames=inputAppNames.split(";");

		for(int k=0;k<appNames.length;k++){

			appNamesListInput.add(appNames[k]);

		}

		//invokeWebDriverWait(60, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_SharedServicesApplicationManagement_xpath);

		WebElement mainTable=createWebElement("xpath",ObjRepo.HomePage_SharedServicesApplicationManagement_xpath);

		List<WebElement>allRows=createWebElements(mainTable,"tagname","tr");

		for(int i=0;i<allRows.size()-1;i++){

			allRows=createWebElements(mainTable,"tagname","tr");

			List<WebElement> allValues=createWebElements(allRows.get(i),"tagname","td");

			System.out.println("column value "+allValues.get(0).getText());

			appNamesList.add(allValues.get(0).getText());

			System.out.println(appNamesList);


		}

		for (String s : appNamesListInput) {
			if (!appNamesList.contains(s)) {
				diffSysViewApps.add(s);
			}
		}

		if(!diffSysViewApps.isEmpty()){

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Application Names in Shared Services","User is able to see the following Applciations: "+appNamesListInput+" Successfully in in Shared Services.","Applciations: "+appNamesList+" are shown successfully. But "+diffSysViewApps+" are not shown in shared services.","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateSharedSericesApplicationsList");

		}
		else{

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Application Names in Shared Services ","User is able to see the following Options: "+appNamesListInput+" Successfully in in Shared Services.","Applciations: "+appNamesList+"are shown successfully.","Pass");
		}

		return this;
	}
	public HomePage getTheSharedServicesApplicationManagementLists() throws Exception{

		try{


			List<WebElement>allTables=createWebElements("tagname", "table");

			System.out.println("tables size"+allTables.size());

			for(int j=0;j<allTables.size();j++){			

				allTables=createWebElements("tagname", "table");

				System.out.println(j+"value are and table values are"+allTables.get(j).getText());
			}

		}


		catch(Exception e){

			System.out.println(e.getMessage());

			e.printStackTrace();
		}
		return this;
	}

	public HomePage clickOnFile() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_File_xpath);

		System.out.println("clicked on File");

		return this;

	}

	public HomePage clickOnPreference() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_Preferences_xpath);

		System.out.println("clicked on Preferences");

		return this;

	}

	public HomePage getTheGeneralPreferenceValuesWithNoApplicationSelected() throws Exception

	{
		String contentVal=null;

		try{

			clickOnEle("xpath", ObjRepo.HomePage_GeneralPreferences_xpath);

			System.out.println("clicked on general");

			contentVal= getText("xpath", ObjRepo.HomePage_GeneralContent_xpath);

			System.out.println("content val "+contentVal);			

			ReportExcel.addstep("WorkSpace Application - Validating 'General' options in Preference Window (in File Menu) - when application is not selected","User is able to see 'None' in content dropdown in General.","User is able to see the "+contentVal+" in content drop down","Pass");

		}
		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating 'General' options in Preference Window (in File Menu) - when application is not selected","User is able to see 'None' in content dropdown in General.","User is able to see the "+contentVal+" in content drop down","Fail");

			ScreenShotLib.takeScreenshotAndSave("validatePlanningOptionsInPreferenceOptionsWhenNoApplicationSelected");

		}

		return this;	
	}

	public HomePage getThePlanningPreferenceValuesWithNoApplicationSelected() throws Exception

	{

		try{
			switchToDefault();

			switchToFrame("tagname", "frame");

			clickOnEle("xpath", ObjRepo.HomePage_PlanningPreferences_xpath);

			System.out.println("clicked on Planning");

			//Thread.sleep(2000);

			switchToFrameById("PlanningPrefs.iframe");

			//Thread.sleep(2000);

			String planningVal=getText("xpath",ObjRepo.HomePage_PlanningPrompt_xpath);

			System.out.println(planningVal);	

			Thread.sleep(2000);

			switchToDefault();

			switchToFrame("tagname", "frame");

			//WebElement buttonVal=createWebElement("classname", "bi-component window-footer-content");

			clickOnEle("xpath", ObjRepo.HomePage_OKInPreferences_xpath);

			System.out.println("clicking on ok");

			ReportExcel.addstep("WorkSpace Application - Validating 'Planning' options in Preference Window (in File Menu) - when application is not selected","User is able to see the required message as 'Please open the Planning application to set application preferences.' in Planning.","User is able to see '"+planningVal+"' in Planning preference window","Pass");

		}

		catch(Exception e){

			e.getMessage();

			e.printStackTrace();

			ReportExcel.addstep("WorkSpace Application - Validating 'Planning' options in Preference Window (in File Menu) - when application is not selected","User is able to see the required message as 'Please open the Planning application to set application preferences.' in Planning.","User is not able to see the required validation message in Planning preference window","Fail");

			ScreenShotLib.takeScreenshotAndSave("validatePlanningOptionsInPreferenceOptionsWhenNoApplicationSelected");

		}

		return this;	
	}

	public HomePage closingOpenedApplications() throws Exception

	{

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_ClosingApplciation_xpath))

				clickOnEle("xpath", ObjRepo.HomePage_ClosingApplciation_xpath);

		}

		catch(Exception e){

			System.out.println("applcations are not opened");
		}
		return this;
	}

	public HomePage OpenApplication(String appName) throws Exception

	{
		clickOnEle("xpath", ".//td[text()='"+appName+"']");

		Thread.sleep(5000);


		return this;

	}

	public HomePage getThePlanningPreferenceValuesWithAnApplicationSelected() throws Exception

	{
		ArrayList<String> options=new ArrayList<String>();

		//try{

		switchToDefault();

		switchToFrame("tagname", "frame");

		clickOnEle("xpath", ObjRepo.HomePage_PlanningPreferences_xpath);

		System.out.println("clicked on Planning");

		Thread.sleep(2000);

		switchToFrameById("PlanningPrefs.iframe");

		switchToFrameById("pref_frame");

		Thread.sleep(2000);

		List<WebElement> allTabs=createWebElements("tagname", "a");

		for(int i=1;i<5;i++){

			System.out.println("Option "+i+" value is "+allTabs.get(i).getText());

			String OptionVal=allTabs.get(i).getText();

			options.add(OptionVal);

		}

		switchToDefault();

		switchToFrame("tagname", "frame");

		clickOnEle("xpath", ObjRepo.HomePage_OKInPreferences_xpath);

		System.out.println("clicked on ok");

		ReportExcel.addstep("WorkSpace Application - Validating 'Planning' options in Preference Window (in File Menu) - when application is selected","User is able to see the required Options as 'Application Settings','Display Options','Printing Options' and 'User Variable Options' in Planning.","User is able to see '"+options+"' in Planning preference window","Pass");

		/*}

		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating 'Planning' options in Preference Window (in File Menu) - when application is not selected","User is able to see the required message as 'Please open the Planning application to set application preferences.' in Planning.","User is not able to see the required validation message in Planning preference window","Fail");

		}*/

		return this;	
	}

	public HomePage validateSelectViewStatus() throws Exception{


		invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_SelectView_xpath);

		try{

			isEnabled("xpath", ObjRepo.HomePage_SelectView_xpath);	

			System.out.println("checking select view");

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Select View status in Calculation Manager","User is able to see the 'Select view' as Enabled Successfully in System View.","Select View is Enabled in calculation Manager","Pass");

		}

		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Select View status in Calculation Manager","User is able to see the 'Select view' as Enabled Successfully in System View.","Select View is disabled in calculation Manager","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateSelectView_View_Actions_Status");

		}


		return this;
	}

	public HomePage validateViewStatus() throws Exception{


		//invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",".//div[@title='Planning']");

		try{

			isEnabled("xpath", ObjRepo.HomePage_View_xpath);

			//clickOnEle("xpath", ObjRepo.HomePage_View_xpath);

			System.out.println("checking view");

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating View status in Calculation Manager","User is able to see the 'View' as Enabled Successfully in  System View.","View is Enabled in System View in calculation Manager","Pass");

		}
		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating View status in Calculation Manager","User is able to see the 'View' as Enabled Successfully in System View.","View is disabled in System View in calculation Manager","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateSelectView_View_Actions_Status");

		}


		return this;
	}


	public HomePage validateActionsStatus() throws Exception{


		//invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",".//div[@title='Planning']");

		try{

			isEnabled("xpath", ObjRepo.HomePage_Actions_xpath);

			//clickOnEle("xpath", ObjRepo.HomePage_Actions_xpath);

			System.out.println("checking Actions");

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Actions status in Calculation Manager","User is able to see the 'Actions' as Enabled Successfully in  System View.","Actions is Enabled in System View in calculation Manager","Pass");

		}
		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Actions status in Calculation Manager","User is able to see the 'Actions' as Enabled Successfully in System View.","Actions is disabled in System View in calculation Manager","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateSelectView_View_Actions_Status");

		}


		return this;
	}


	public HomePage validateRulesInPlanningSystemView(String appnName,String cubeName) throws Exception{

		ArrayList<String>lstRuleFileNames=new ArrayList<String>();

		try{

			clickOnEle("xpath", ObjRepo.HomePage_PlanningNameExpand_xpath);

			Thread.sleep(2000);

			clickOnEle("xpath","//img[@alt='"+appnName+"']/../span");

			Thread.sleep(2000);

			WebElement cubeTable=createWebElement("xpath", ObjRepo.HomePage_CubeTableInPlanning_xpath);	

			List<WebElement>appnCubeRows=createWebElements(cubeTable, "tagname", "tr");

			System.out.println("size of appnCubeRows"+appnCubeRows.size());

			for(int m=0;m<appnCubeRows.size();m++){

				appnCubeRows=createWebElements(cubeTable, "tagname", "tr");

				List<WebElement>appnCubeNames=createWebElements(appnCubeRows.get(m), "tagname", "td");

				System.out.println(appnCubeNames.get(0).getText());

				String cbeName=appnCubeNames.get(0).getText();

				if(cbeName.equalsIgnoreCase(cubeName)){

					WebElement cube=createWebElement(appnCubeNames.get(0),"classname", "xst");

					cube.click();

					System.out.println("clicking on cube "+cbeName);

					break;

				}

			}

			Thread.sleep(2000);

			List<WebElement>allTables=createWebElements("tagname", "table");

			System.out.println("tables size is before expanding rules "+allTables.size());

			clickOnEle("xpath",ObjRepo.HomePage_Rules_xpath);			

			Thread.sleep(3000);

			List<WebElement>allTables1=createWebElements("tagname", "table");

			System.out.println("tables size is after expanding rules "+allTables1.size());

			if(allTables.size()!=allTables1.size()){

				WebElement ruleFilesTable=createWebElement("xpath", ObjRepo.HomePage_RuleFilesInPlanning_xpath);	

				List<WebElement>ruleFilesRows=createWebElements(ruleFilesTable, "tagname", "tr");

				System.out.println("size of appnCubeRows"+ruleFilesRows.size());

				for(int i=0;i<ruleFilesRows.size();i++){

					ruleFilesRows=createWebElements(ruleFilesTable, "tagname", "tr");

					List<WebElement>ruleFileNames=createWebElements(ruleFilesRows.get(i), "tagname", "td");

					System.out.println(ruleFileNames.get(0).getText());

					String cbeName=ruleFileNames.get(0).getText();

					lstRuleFileNames.add(cbeName);

				}


				ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Rules In the Planning System View in Calculation Manager","User is able to see the Rule files in Rule for the Application of "+appnName+" and the cube "+cubeName+" in planning System View Successfully.","RuleFiles "+lstRuleFileNames+" are present in Rules for the cube "+cubeName+" and the application "+appnName,"Pass");

			}

			else

			{
				ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Rules In the Planning System View in Calculation Manager","User is able to see the Rule files in Rule for the Application of "+appnName+" and the cube "+cubeName+" in planning System View Successfully.","There are no RuleFiles in Rules for the cube "+cubeName+" and the application "+appnName,"Pass");

			}

		}

		catch(Exception e){

			System.out.println("issue is with clicking on Rules in Planning System View "+e.getMessage()+". Rules Folder is not available");

			e.printStackTrace();

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Rules In the Planning System View in Calculation Manager","User is able to see the Rule files in Rule for the Application of "+appnName+" and the cube "+cubeName+" in planning System View Successfully.","Issue is with clicking on Rules in Planning System View "+e.getMessage()+" as  'Rules' file is not avaiable.","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateRuleFilesInPlanning");
		}

		clickOnEle("xpath","//img[@alt='"+appnName+"']/../span");

		Thread.sleep(2000);

		clickOnEle("xpath", ObjRepo.HomePage_PlanningNameExpand_xpath);

		switchToDefault();

		switchToFrame("tagname", "frame");

		//clickOnEle("xpath", ObjRepo.HomePage_ClosingApplciation_xpath);

		return this;
	}

	public HomePage validateRulesInEssbaseSystemView(String appnName,String cubeName) throws Exception{

		ArrayList<String>lstRuleFileNames=new ArrayList<String>();

		try{

			Thread.sleep(3000);

			clickOnEle("xpath", ObjRepo.HomePage_EssbaseNameExpand_xpath);

			Thread.sleep(2000);

			clickOnEle("xpath","//img[@alt='"+appnName+"']/../span");

			Thread.sleep(2000);

			WebElement cubeTable=createWebElement("xpath", ObjRepo.HomePage_CubeTableAndRuleFilesTableInEssBase_xpath);	

			List<WebElement>appnCubeRows=createWebElements(cubeTable, "tagname", "tr");

			System.out.println("size of appnCubeRows"+appnCubeRows.size());

			for(int m=0;m<appnCubeRows.size();m++){

				appnCubeRows=createWebElements(cubeTable, "tagname", "tr");

				List<WebElement>appnCubeNames=createWebElements(appnCubeRows.get(m), "tagname", "td");

				System.out.println(appnCubeNames.get(0).getText());

				String cbeName=appnCubeNames.get(0).getText();

				if(cbeName.equalsIgnoreCase(cubeName)){

					WebElement cube=createWebElement(appnCubeNames.get(0),"classname", "xst");

					cube.click();

					System.out.println("clicking on cube "+cbeName);

					break;

				}

			}

			Thread.sleep(2000);

			List<WebElement>allTables=createWebElements("tagname", "table");

			System.out.println("tables size is before expanding rules "+allTables.size());

			clickOnEle("xpath",ObjRepo.HomePage_Rules_xpath);			

			Thread.sleep(3000);

			List<WebElement>allTables1=createWebElements("tagname", "table");

			System.out.println("tables size is after expanding rules "+allTables1.size());

			if(allTables.size()!=allTables1.size()){

				WebElement ruleFilesTable=createWebElement("xpath", ObjRepo.HomePage_CubeTableAndRuleFilesTableInEssBase_xpath);	

				List<WebElement>ruleFilesRows=createWebElements(ruleFilesTable, "tagname", "tr");

				System.out.println("size of appnCubeRows"+ruleFilesRows.size());

				for(int i=0;i<ruleFilesRows.size();i++){

					ruleFilesRows=createWebElements(ruleFilesTable, "tagname", "tr");

					List<WebElement>ruleFileNames=createWebElements(ruleFilesRows.get(i), "tagname", "td");

					System.out.println(ruleFileNames.get(0).getText());

					String cbeName=ruleFileNames.get(0).getText();

					lstRuleFileNames.add(cbeName);

				}

				ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Rules In the Essbase System View in Calculation Manager","User is able to see the Rule files in Rule for the Application of "+appnName+" and the cube "+cubeName+" in Essbase System View Successfully.","RuleFiles "+lstRuleFileNames+" are present in Rules for the cube "+cubeName+" and the application "+appnName,"Pass");

			}

			else

			{

				ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Rules In the Essbase System View in Calculation Manager","User is able to see the Rule files in Rule for the Application of "+appnName+" and the cube "+cubeName+" in Essbase System View Successfully.","There are no RuleFiles in Rules for the cube "+cubeName+" and the application "+appnName,"Pass");

			}

		}

		catch(Exception e){

			System.out.println("issue is with cliecking on Rules in Essbase System View"+e.getMessage());

			e.printStackTrace();

			ReportExcel.addstep("WorkSpace Application - Validating Navigation to all Components : Validating Rules In the Essbase System View in Calculation Manager","User is able to see the Rule files in Rule for the Application of "+appnName+" and the cube "+cubeName+" in Essbase System View Successfully.","Issue is with clicking on Rules in Essbase System View"+e.getMessage(),"Fail");

			ScreenShotLib.takeScreenshotAndSave("validateRuleFilesInEssbase");
		}

		clickOnEle("xpath","//img[@alt='"+appnName+"']/../span");

		Thread.sleep(2000);	

		clickOnEle("xpath", ObjRepo.HomePage_EssbaseNameExpand_xpath);

		switchToDefault();

		switchToFrame("tagname", "frame");

		clickOnEle("xpath", ObjRepo.HomePage_ClosingApplciation_xpath);


		return this;
	}

	public HomePage clickOnWorkSpaceSettings() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_WorkSpaceSettings_xpath);

		System.out.println("clicked on Workspace Settings option");

		return this;

	}
	public HomePage clickOnServerSettings() throws Exception

	{
		clickOnEle("xpath", ObjRepo.HomePage_ServerSettings_xpath);

		System.out.println("clicked on server settings option");

		return this;

	}

	public HomePage ValidateAllTheFields() throws Exception

	{

		try{

			invokeWebDriverWait(60, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_WorkSpaceServerSettingsWindowHeader_xpath);

			WebElement supportLocale=createWebElement("xpath", ObjRepo.HomePage_SupportedLocales_xpath);

			if(supportLocale.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Supported Locales: field status in Workspace Server Settigs Active Window","User is able to see the 'Supported Locales:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Supported Locales:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Supported Locales: field status in Workspace Server Settigs Active Window","User is able to see the 'Supported Locales:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Supported Locales:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Supported Locales: status"+e.getMessage());

			e.printStackTrace();
		}


		try{

			WebElement defaultLocale=createWebElement("xpath", ObjRepo.HomePage_DefaultLocale_xpath);

			if(defaultLocale.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Default Locale: field status in Workspace Server Settigs Active Window","User is able to see the 'Default Locale:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Default Locale:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Default Locale: field status in Workspace Server Settigs Active Window","User is able to see the 'Default Locale:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Default Locale:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Default Locale: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement clientDebug=createWebElement("xpath", ObjRepo.HomePage_clientDebug_xpath);

			if(clientDebug.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Client Debug Enabled: field status in Workspace Server Settigs Active Window","User is able to see the 'Client Debug Enabled:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Client Debug Enabled:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Client Debug Enabled: field status in Workspace Server Settigs Active Window","User is able to see the 'Client Debug Enabled:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Client Debug Enabled:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Client Debug Enabled: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement sessionTimeOut=createWebElement("xpath", ObjRepo.HomePage_SessionTimeOut_xpath);

			if(sessionTimeOut.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Session Timeout (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Session Timeout (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Session Timeout (minutes):' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Session Timeout (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Session Timeout (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Session Timeout (minutes):' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Session Timeout (minutes): status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement KeepAliveEnv=createWebElement("xpath", ObjRepo.HomePage_KeepAliveInterval_xpath);

			if(KeepAliveEnv.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Keep-Alive Interval (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Keep-Alive Interval (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Keep-Alive Interval (minutes):' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Keep-Alive Interval (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Keep-Alive Interval (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Keep-Alive Interval (minutes):' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Keep-Alive Interval (minutes): status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement reqLogon=createWebElement("xpath", ObjRepo.HomePage_RequiredLogon_xpath);

			if(reqLogon.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Required Logon Role: field status in Workspace Server Settigs Active Window","User is able to see the 'Required Logon Role:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Required Logon Role:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Required Logon Role: field status in Workspace Server Settigs Active Window","User is able to see the 'Required Logon Role:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Required Logon Role:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Required Logon Role: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement nativePwdChge=createWebElement("xpath", ObjRepo.HomePage_EnableNativeUserPasswordChange_xpath);

			if(nativePwdChge.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enable Native User Password Change: field status in Workspace Server Settigs Active Window","User is able to see the 'Enable Native User Password Change:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enable Native User Password Change:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enable Native User Password Change: field status in Workspace Server Settigs Active Window","User is able to see the 'Enable Native User Password Change:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enable Native User Password Change:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Enable Native User Password Change: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement httpReq=createWebElement("xpath", ObjRepo.HomePage_HTTPRequestURL_xpath);

			if(httpReq.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Accept Credentials in a HTTP Request URL: field status in Workspace Server Settigs Active Window","User is able to see the 'Accept Credentials in a HTTP Request URL:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Accept Credentials in a HTTP Request URL:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Accept Credentials in a HTTP Request URL: field status in Workspace Server Settigs Active Window","User is able to see the 'Accept Credentials in a HTTP Request URL:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Accept Credentials in a HTTP Request URL:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Enable Native User Password Change: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement directlogon=createWebElement("xpath", ObjRepo.HomePage_AllowDirectLogon_xpath);

			if(directlogon.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Allow Direct Logon After SSO Failure: field status in Workspace Server Settigs Active Window","User is able to see the 'Allow Direct Logon After SSO Failure:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Allow Direct Logon After SSO Failure:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating AAllow Direct Logon After SSO Failure: field status in Workspace Server Settigs Active Window","User is able to see the 'Allow Direct Logon After SSO Failure:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Allow Direct Logon After SSO Failure:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Enable Native User Password Change: status"+e.getMessage());

			e.printStackTrace();
		}


		try{

			WebElement usrDisNme=createWebElement("xpath", ObjRepo.HomePage_EnableUserDisplayName_xpath);

			if(usrDisNme.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enable User Display Name: field status in Workspace Server Settigs Active Window","User is able to see the 'Enable User Display Name:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enable User Display Name:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enable User Display Name: field status in Workspace Server Settigs Active Window","User is able to see the 'Enable User Display Name:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enable User Display Name:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Enable Native User Password Change: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement unAtLgn=createWebElement("xpath", ObjRepo.HomePage_RememberUserNameAtLogon_xpath);

			if(unAtLgn.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Remember User Name at Logon: field status in Workspace Server Settigs Active Window","User is able to see the 'Remember User Name at Logon:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Remember User Name at Logon:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Remember User Name at Logon: field status in Workspace Server Settigs Active Window","User is able to see the 'Remember User Name at Logon:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Remember User Name at Logon:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking ERemember User Name at Logon: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement msgFile=createWebElement("xpath", ObjRepo.HomePage_MessageFile_xpath);

			if(msgFile.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Message File: field status in Workspace Server Settigs Active Window","User is able to see the 'Message File:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Message File:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Message File: field status in Workspace Server Settigs Active Window","User is able to see the 'Message File:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Message File:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Message File: status"+e.getMessage());

			e.printStackTrace();
		}


		try{

			WebElement pollIntrval=createWebElement("xpath", ObjRepo.HomePage_ClientMessagePollingInterval_xpath);

			if(pollIntrval.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Client Message Polling Interval (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Client Message Polling Interval (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Client Message Polling Interval (minutes):' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Client Message Polling Interval (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Client Message Polling Interval (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Client Message Polling Interval (minutes):' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Client Message Polling Interval (minutes): status"+e.getMessage());

			e.printStackTrace();
		}


		try{

			WebElement msgCache=createWebElement("xpath", ObjRepo.HomePage_ServerMessageCache_xpath);

			if(msgCache.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Server Message Cache (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Server Message Cache (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Server Message Cache (minutes):' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Server Message Cache (minutes): field status in Workspace Server Settigs Active Window","User is able to see the 'Server Message Cache (minutes):' as Enabled Successfully in Workspace Server Settigs Active Window.","'Server Message Cache (minutes):' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Server Message Cache (minutes): status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement usrProdKit=createWebElement("xpath", ObjRepo.HomePage_URItoUserProductivityKit_xpath);

			if(usrProdKit.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating URI to User Productivity Kit: field status in Workspace Server Settigs Active Window","User is able to see the 'URI to User Productivity Kit:' as Enabled Successfully in Workspace Server Settigs Active Window.","'URI to User Productivity Kit:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating URI to User Productivity Kit: field status in Workspace Server Settigs Active Window","User is able to see the 'URI to User Productivity Kit:' as Enabled Successfully in Workspace Server Settigs Active Window.","'URI to User Productivity Kit:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking URI to User Productivity Kit: status"+e.getMessage());

			e.printStackTrace();
		}


		try{

			WebElement logoffUrl=createWebElement("xpath", ObjRepo.HomePage_PostLogoffURL_xpath);

			if(logoffUrl.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Post Logoff URL: field status in Workspace Server Settigs Active Window","User is able to see the 'Post Logoff URL:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Post Logoff URL:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Post Logoff URL: field status in Workspace Server Settigs Active Window","User is able to see the 'Post Logoff URL:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Post Logoff URL:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Post Logoff URL: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement smtviwUrl=createWebElement("xpath", ObjRepo.HomePage_SmartViewURI_xpath);

			if(smtviwUrl.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Smart View URI: field status in Workspace Server Settigs Active Window","User is able to see the 'Smart View URI:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Smart View URI:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Smart View URI: field status in Workspace Server Settigs Active Window","User is able to see the 'Smart View URI:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Smart View URI:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Smart View URI: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement enableInstal=createWebElement("xpath", ObjRepo.HomePage_EnableInstallerMenuItemsInWorkspace_xpath);

			if(enableInstal.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enable Installer Menu Items in Workspace: field status in Workspace Server Settigs Active Window","User is able to see the 'Enable Installer Menu Items in Workspace:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enable Installer Menu Items in Workspace:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enable Installer Menu Items in Workspace: field status in Workspace Server Settigs Active Window","User is able to see the 'Enable Installer Menu Items in Workspace:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enable Installer Menu Items in Workspace:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Enable Installer Menu Items in Workspace: status"+e.getMessage());

			e.printStackTrace();
		}

		try{

			WebElement enbleProd=createWebElement("xpath", ObjRepo.HomePage_EnabledProducts_xpath);

			if(enbleProd.isEnabled()){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enabled Products: field status in Workspace Server Settigs Active Window","User is able to see the 'Enabled Products:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enabled Products:' is Enabled in Workspace Server Settigs Active Window.","Pass");

			}

			else{

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Enabled Products: field status in Workspace Server Settigs Active Window","User is able to see the 'Enabled Products:' as Enabled Successfully in Workspace Server Settigs Active Window.","'Enabled Products:' is Disabled in Workspace Server Settigs Active Window.","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");
			}

		}

		catch(Exception e){

			System.out.println("issue is with checking Enabled Products: status"+e.getMessage());

			e.printStackTrace();
		}


		return this;

	}

	public HomePage clickOnOkInWorkspaceServerSettingsWindow() throws Exception{

		try{

			clickOnEle("xpath", ObjRepo.HomePage_OKInServerSettings_xpath);

			System.out.println("clicked on ok button");

		}

		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Clicking on OK in Workspace Server Settigs Active Window","User is able to click on the OK button Successfully in Workspace Server Settigs Active Window.","Couldn't able to click on OK button . Because of the following issue:"+e.getMessage(),"Fail");

			ScreenShotLib.takeScreenshotAndSave("validateCalculationManagerComponents");

		}


		return this;
	}


	public HomePage getTheUserDirectoriesOptionsInUsersForUserDirectoriesInSameTimeLDAPInSharedServicesConsole() throws Exception{

		//try{

		invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_UserDirectories_xpath);

		clickOnEle("xpath", ObjRepo.HomePage_UserDirectoriesArrow_xpath);

		System.out.println("clicked on ok User Directories");

		clickOnEle("xpath", ObjRepo.HomePage_SameTimeLDAPArrow_xpath);

		System.out.println("clicked on ok SameTimeLDAP ");	

		clickOnEle("xpath", ObjRepo.HomePage_Users_xpath);

		System.out.println("clicked on ok Users ");

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_UserProperty_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'User Property' in Users provision in SameTimeLDAP","'User Property' exists in Users provision in SameTimeLDAP ","Pass");

			}

		}catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'User Property' in Users provision in SameTimeLDAP","'User Property' does not exist in Users provision in SameTimeLDAP ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");
		}

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_UserFilter_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'User Filter' in Users provision in SameTimeLDAP","'User Filter' exists in Users provision in SameTimeLDAP ","Pass");

			}
		}

		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'User Filter' in Users provision in SameTimeLDAP","'User Filter' does not exist in Users provision in SameTimeLDAP ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");

		}

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_InGroupsField_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'In Group(s)' in Users provision in SameTimeLDAP","'In Group(s)' exists in Users provision in SameTimeLDAP ","Pass");

			}
		}
		catch(Exception e)

		{

			ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'In Group(s)' in Users provision in SameTimeLDAP","'In Group(s)' does not exist in Users provision in SameTimeLDAP ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");

		}

		try{


			if(existsOrNot("xpath", ObjRepo.HomePage_PageSize_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'Page Size' in Users provision in SameTimeLDAP","'Page Size' exists in Users provision in SameTimeLDAP ","Pass");

			}
		}

		catch(Exception e)

		{

			ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console ","User is able to see the option 'Page Size' in Users provision in SameTimeLDAP","'Page Size' does not exist in Users provision in SameTimeLDAP ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");

		}

		return this;
	}

	public HomePage getTheUsersList(String userName) throws Exception{

		ArrayList<String> userNames=new ArrayList<String>();

		ArrayList<String> lstSelectedGroups=new ArrayList<String>();

		invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_SearchCriteriaMessage_xpath);

		//clearText("xpath", "//div[text()='User Filter']/following::button");

		setValue("xpath", ObjRepo.HomePage_UserFilterTextField_xpath, userName);

		Thread.sleep(2000);

		System.out.println("entered the user name value");

		clickOnEle("id", ObjRepo.HomePage_SearchButton_id);

		Thread.sleep(8000);

		List<WebElement> table=createWebElements("xpath", ObjRepo.HomePage_UserOrGroupNamesTable_xpath);

		//waitTime("id", "cas.Project.loading");

		List<WebElement> lstUsersRows=createWebElements(table.get(1),"tagname", "tr");

		for(int i=0;i<lstUsersRows.size();i++){

			lstUsersRows=createWebElements(table.get(1),"tagname", "tr");

			List<WebElement> lstUsers=createWebElements(lstUsersRows.get(i),"tagname", "td");

			System.out.println(i+" value and main column values are "+lstUsers.get(0).getText());

			userNames.add(lstUsers.get(0).getText());

		}

		ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Getting 'User Names' list in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console","User is able to get all the avaiable User Names in Users","User Names list "+userNames+" are available in Users","Pass");

		if(lstUsersRows.size()>0){
			try{
				clickOnEle("xpath", ".//*[text()='"+userNames.get(0)+"']");

				System.out.println("user name is "+userNames.get(0));

				System.out.println("click on row");

				Thread.sleep(2000);

				clickOnEle("xpath", ObjRepo.HomePage_PropertiesIcon_xpath);			

				invokeWebDriverWait(30, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_UserPropertiesWindow_xpath);

				switchToFrameById("cas.defaultdialog.iFrame");

				//Thread.sleep(8000);

				invokeWebDriverWait(30, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_MemberOf_xpath);

				clickOnEle("xpath", ObjRepo.HomePage_MemberOf_xpath);

				//			List<WebElement>lstGropsRows=createWebElements("xpath", ".//table[@id='groupSelect']");

				WebElement lstSelectedGropsRowsTable=createWebElement("xpath", ObjRepo.HomePage_SelectedGroupsList_xpath);

				List<WebElement>lstSelectedGroupRows=createWebElements(lstSelectedGropsRowsTable,"tagname","tr");

				System.out.println(lstSelectedGroupRows.size());

				for(int i=1;i<lstSelectedGroupRows.size();i++){

					lstSelectedGroupRows=createWebElements(lstSelectedGropsRowsTable,"tagname","tr");

					List<WebElement>lstSelectedGroupNames=createWebElements(lstSelectedGroupRows.get(i),"tagname","td");

					System.out.println(lstSelectedGroupNames.get(1).getText());

					lstSelectedGroups.add(lstSelectedGroupNames.get(1).getText());	

					clickOnEle("id", ObjRepo.HomePage_OKButtonInUserProperties_ID);

					clickOnEle("classname", ObjRepo.HomePage_OKButtonInUserPropertiesErrorWindow_className);

				}

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating assigned Groups for an user in Users(Shared Services-->User Directories->SameTimeLDAP->Users->Properties)in Shared Services Console","User is able to see the 'Assigned groups' in properties for "+userNames.get(0)+" User in Users","Assigned Groups "+lstSelectedGroups+" in properties for "+userNames.get(0)+" User in Users","Pass");

			}

			catch(Exception e){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating assigned Groups for an user in Users(Shared Services-->User Directories->SameTimeLDAP->Users->Properties)in Shared Services Console","User is able to see the 'Assigned groups' in properties for "+userNames.get(0)+" User in Users","We are not able to get the Assigned Groups in properties for "+userNames.get(0)+" User in Users. Because of the following issue "+e.getMessage(),"Fail");

				ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");

			}
			switchToDefault();

			switchToFrame("tagname", "frame");

			clickOnEle("xpath", ".//*[text()='"+userNames.get(0)+"']");

			System.out.println("user name is "+userNames.get(0));

			System.out.println("click on row");

			Thread.sleep(2000);

			clickOnEle("xpath", ObjRepo.HomePage_Provision_xpath);

			switchToFrameById("css.users.manage");

			invokeWebDriverWait(30, "visibilityofelementlocated", "xpath",".//span[text()='Provision: "+userNames.get(0)+"']");

			try{

				if(existsOrNot("xpath", ".//span[text()='Provision: "+userNames.get(0)+"']")){

					ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Provisioning tab for an user in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console","User is able to see the 'Provisioning' tab for "+userNames.get(0)+" User in Users","'Provisioning' tab got opened for "+userNames.get(0)+" User in Users","Pass");

				}

			}

			catch(Exception e){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Provisioning tab for an user in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console","User is able to see the 'Provisioning' tab for "+userNames.get(0)+" User in Users","'Provisioning' tab didn't get open for "+userNames.get(0)+" User in Users","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");

			}

		}

		else {

			ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Provisioning tab for an user in Users(Shared Services-->User Directories->SameTimeLDAP->Users)in Shared Services Console","User is able to see the 'Provisioning' tab for "+userNames.get(0)+" User in Users","There are no users names in Users","Warn");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForSameTimeLDAPInUserDirectoriesForSharedServicesConsole");

		}

		switchToDefault();

		switchToFrame("tagname", "frame");

		//clickOnEle("xpath", ObjRepo.HomePage_ClosingApplciation_xpath);


		return this;
	}


	public HomePage getTheUserDirectoriesOptionsInUsersForUserDirectoriesInNativeDirectoryInSharedServicesConsole() throws Exception{

		//try{

		//invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",".//td[text()='User Directories']");

		clickOnEle("xpath", ObjRepo.HomePage_SameTimeLDAPArrow_xpath);

		System.out.println("clicked on ok SameTimeLDAP ");	

		clickOnEle("xpath", ObjRepo.HomePage_NativeDirectory_xpath);

		System.out.println("clicked on Native Directory ");	

		clickOnEle("xpath", ObjRepo.HomePage_Groups_xpath);

		System.out.println("clicked on ok Groups ");

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_GroupProperty_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Groups(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console ","User is able to see the option 'Group Property' in Groups provision in Native Directory","'Group Property' exists in Groups provision in Native Directory ","Pass");

			}

		}catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Options in Groups(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console ","User is able to see the option 'Group Property' in Groups provision in Native Directory","'Group Property' does not exist in Groups provision in Native Directory ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForNativeDirectoryInUserDirectoriesForSharedServicesConsole");
		}

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_GroupFilter_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Groups(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console ","User is able to see the option 'Group Filter' in Groups provision in Native Directory","'Group Filter' exists in Groups provision in Native Directory ","Pass");

			}
		}

		catch(Exception e){

			ReportExcel.addstep("WorkSpace Application - Validating Options in Groups(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console ","User is able to see the option 'Group Filter' in Groups provision in Native Directory","'Group Filter' does not exist in Groups provision in Native Directory ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForNativeDirectoryInUserDirectoriesForSharedServicesConsole");

		}

		try{

			if(existsOrNot("xpath", ObjRepo.HomePage_PageSize_xpath)){

				ReportExcel.addstep("WorkSpace Application - Validating Options in Groups(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console ","User is able to see the option 'Page Size' in Groups provision in Native Directory","'Page Size' exists in Groups provision in Native Directory ","Pass");

			}
		}

		catch(Exception e)

		{

			ReportExcel.addstep("WorkSpace Application - Validating Options in Users(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console ","User is able to see the option 'Page Size' in Groups provision in Native Directory","'Page Size' does not exist in Groups provision in Native Directory ","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForNativeDirectoryInUserDirectoriesForSharedServicesConsole");

		}

		return this;
	}

	public HomePage getTheGroupsList(String groupName) throws Exception{

		ArrayList<String> groupNames=new ArrayList<String>();

		//invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",".//td[text()='Enter search criteria to begin.']");

		//clickOnEle("xpath", "//div[text()='User Filter']/following::button");

		setValue("xpath", ObjRepo.HomePage_GroupFilterTextField_xpath, groupName);

		clickOnEle("id", "GridBtn");

		Thread.sleep(7000);

		//waitTime("id", "cas.Project.loading");

		//Thread.sleep(8000);

		List <WebElement> table=createWebElements("xpath", ObjRepo.HomePage_UserOrGroupNamesTable_xpath);

		//waitTime("id", "cas.Project.loading");

		List<WebElement> lstUsersRows=createWebElements(table.get(1),"tagname", "tr");

		for(int i=0;i<lstUsersRows.size();i++){

			lstUsersRows=createWebElements(table.get(1),"tagname", "tr");

			List<WebElement> lstUsers=createWebElements(lstUsersRows.get(i),"tagname", "td");

			System.out.println(i+" value and main column values are "+lstUsers.get(0).getText());

			groupNames.add(lstUsers.get(0).getText());

		}

		ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Getting 'Group Names' list in Groups(Shared Services-->User Directories->Native Directory->Groups)in Shared Services Console","User is able to get all the avaiable Group Names in Groups","User Names list "+groupNames+" are available in Groups","Pass");


		if(lstUsersRows.size()>0){


			clickOnEle("xpath", ".//*[text()='"+groupNames.get(0)+"']");

			System.out.println("user name is "+groupNames.get(0));

			System.out.println("click on row");

			Thread.sleep(2000);

			clickOnEle("xpath", ObjRepo.HomePage_Provision_xpath);

			switchToFrameById("css.groups.manage");

			invokeWebDriverWait(30, "visibilityofelementlocated", "xpath",".//span[text()='Provision: "+groupNames.get(0)+"']");

			try{

				if(existsOrNot("xpath", ".//span[text()='Provision: "+groupNames.get(0)+"']")){

					ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Provisioning tab for an group in Groups(Shared Services-->User Directories->SameTimeLDAP->Groups)in Shared Services Console","User is able to see the 'Provisioning' tab for "+groupNames.get(0)+" group in groups","'Provisioning' tab got opened for "+groupNames.get(0)+" group in Groups","Pass");

				}

			}

			catch(Exception e){

				ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Provisioning tab for an group in Groups(Shared Services-->User Directories->SameTimeLDAP->Groups)in Shared Services Console","User is able to see the 'Provisioning' tab for "+groupNames.get(0)+" group in groups","'Provisioning' tab didn't get open for "+groupNames.get(0)+" group in Groups","Fail");

				ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForNativeDirectoryInUserDirectoriesForSharedServicesConsole");


			}


		}

		else {

			ReportExcel.addstep("WorkSpace Application - Validating Worskspace Server Settings: Validating Provisioning tab for a group in Groups(Shared Services-->User Directories->SameTimeLDAP->Groups)in Shared Services Console","User is able to see the 'Provisioning' tab for "+groupNames.get(0)+" group in Groups","There are no Group names in Groups","Warn");

			ScreenShotLib.takeScreenshotAndSave("validateOptionsAndUserNamesInUsersForNativeDirectoryInUserDirectoriesForSharedServicesConsole");

		}

		switchToDefault();

		switchToFrame("tagname", "frame");

		clickOnEle("xpath", ObjRepo.HomePage_NativeDirectory_xpath);

		System.out.println("clicked on Native Directory ");	

		invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",ObjRepo.HomePage_UserDirectories_xpath);

		clickOnEle("xpath", ObjRepo.HomePage_UserDirectoriesArrow_xpath);

		//clickOnEle("xpath",".//div[text()='Shared Services']/following::img");

		return this;
	}


	//HFM functions start


	public HomePage clickOnConsolidationAdministration() throws Exception

	{

		clickOnEle("xpath", ObjRepo.HFMHomePage_ConsolidationAdministration_xpath);

		System.out.println("clicked on Consolidation Administration");
		
		switchToFrame("xpath", ObjRepo.HFMHomePage_AppFrame_xpath);
		
		invokeWebDriverWait(60, "visibilityofelementlocated", "xpath",ObjRepo.HFMHomePage_ApplicationsImage_xpath);
		
		if(existsOrNot("xpath",ObjRepo.HFMHomePage_ApplicationsImage_xpath)){
			
			ReportExcel.addstep("HFM Application - HealthCheck : Validating Health check of Application Names in Consolidation Administration ","User is able to access Consolidation Administration Successfully.","Consolidation Administration is getting opened successfully.","Pass");
		
		}
		
		else{
			
			ReportExcel.addstep("HFM Application - HealthCheck : Validating Health check of Application Names in Consolidation Administration ","User is able to access Consolidation Administration Successfully.","Consolidation Administration is not accessible.","Fail");
			
			ScreenShotLib.takeScreenshotAndSave("openAnApplicationInConsolidationAdministration");
			
		}
		
		

		return this;

	}

	public HomePage clickOnApplicationsInAdminTasks() throws Exception

	{
		//Thread.sleep(10000);

		//switchToFrame("xpath", ".//iframe[@src='http://10.34.66.188:19000/hfmadf/faces/hfm.jspx?themeSelection=Skyros&accessibilityMode=false']");

		//invokeWebDriverWait(60, "visibilityofelementlocated", "xpath",".//img[@alt='Applications']");

		doubleClickOn("xpath", ObjRepo.HFMHomePage_Application_xpath);

		System.out.println("clicked on  Applications");


		return this;

	}

	public HomePage clickOnApplicationName() throws Exception

	{

		WebElement mainTable=createWebElement("xpath", ObjRepo.HFMHomePage_ApplicationsTable_xpath);


		List<WebElement>lstOfRows=createWebElements(mainTable,"tagname", "tr");

		for(int i=0;i<lstOfRows.size();i++){

			lstOfRows=createWebElements(mainTable,"tagname", "tr");			

			List<WebElement>lstOfappNames=createWebElements(lstOfRows.get(i),"tagname", "td");

			doubleClick(lstOfRows.get(i));			

			String appName=lstOfappNames.get(0).getText();

			System.out.println("clicked on application "+appName);

			Thread.sleep(5000);

			switchToDefault();

			switchToFrame("tagname", "frame");

			//clickOnEle("id","hfm.mnbt_Consolidation");

			try{

				invokeWebDriverWait(180, "visibilityofelementlocated","id",ObjRepo.HFMHomePage_ConsolidationMenuOption_id);

				ReportExcel.addstep("HFM Application - HealthCheck : Validating Health check of Application Names in Consolidation Administration ","User is able to open the following Applciation: "+appName+" Successfully in Consolidation Administration.","Application: "+appName+" is getting opened successfully.","Pass");

			}



			catch(Exception e){

				ReportExcel.addstep("HFM Application - HealthCheck : Validating Health check of Application Names in Consolidation Administration ","User is able to open the following Applciation: "+appName+" Successfully in Consolidation Administration.","Application: "+appName+" is not getting opened successfully.","Fail");

				ScreenShotLib.takeScreenshotAndSave("openAnApplicationInConsolidationAdministration");

			}


			clickOnEle("xpath",".//div[text()='"+appName+"']/parent::div/img[@alt='Close']");

		}

		clickOnEle("xpath",ObjRepo.HFMHomePage_ConsolidationAdministrationTabClose_xpath);

		return this;

	}


	public HomePage clickOnDataManagement() throws Exception

	{

		clickOnEle("xpath", ObjRepo.HFMHomePage_DataManagement_xpath);

		System.out.println("clicked on Data Management");
		
		switchToFrame("xpath", ObjRepo.HFMHomePage_DataManagementFrame_xpath);
		
		invokeWebDriverWait(60, "visibilityofelementlocated","linktext", ObjRepo.HFMHomePage_ProcessDetails_linktext);			
		
           if(existsOrNot("linktext",  ObjRepo.HFMHomePage_ProcessDetails_linktext)){
			
        	   ReportExcel.addstep("HFM Application - Data Management HealthCheck : Validating Process Details page in Data Management","User is able to access Data Management Successfully","User is able to see the Data Management Page successfully.","Pass");
		
		}
		
		else{
			
			ReportExcel.addstep("HFM Application - Data Management HealthCheck : Validating Process Details page in Data Management","User is able to access Data Management Successfully","User is able to access the Data Management Page.","Fail");
			
			ScreenShotLib.takeScreenshotAndSave("validateProcessDetailsInDataManagement");
			
		}
		

		return this;

	}

	public HomePage clickOnProcessDetails() throws Exception

	{

		//switchToFrame("xpath", ".//iframe[@src='http://10.34.66.188:19000/aif/faces/mainPage']");
		/*	String pagTitle1=driver.getTitle();

		System.out.println("title of the page "+pagTitle1);*/

		clickOnEle("linktext",  ObjRepo.HFMHomePage_ProcessDetails_linktext);

		System.out.println("clicked on Process Details");

		return this;

	}

	public HomePage validateProcessDetailsPage() throws Exception

	{

		try{

			invokeWebDriverWait(60, "visibilityofelementlocated", "xpath",ObjRepo.HFMHomePage_ProcessDetails_xpath);

			ReportExcel.addstep("HFM Application - Data Management HealthCheck : Validating Process Details page in Data Management","User is able to open the Process Details Page Successfully in Data Management.","User is able to see the Process Details Page successfully.","Pass");


		}

		catch(Exception e){

			ReportExcel.addstep("HFM Application - Data Management HealthCheck : Validating Process Details page in Data Management","User is able to open the Process Details Page Successfully in Data Management.","User is not able to see the Process Details Page successfully.","Fail");

			ScreenShotLib.takeScreenshotAndSave("validateProcessDetailsInDataManagement");

		}
		
		switchToDefault();

		switchToFrame("tagname", "frame");
		
		clickOnEle("xpath", ObjRepo.HFMHomePage_DataManagementCloseTab_xpath);

		return this;

	}

	public HomePage expandAllTheDirectories() throws Exception

	{

		List<WebElement> lstExpands= createWebElements("xpath", ".//img[@title='Expand']");		

		System.out.println("size of expands are"+lstExpands.size());

		for(int i=0;i<18;i++){

			lstExpands= createWebElements("xpath", ".//img[@title='Expand']");		

			//	clickOnEle(lstExpands.get(i));

			clickOnEle("xpath", ".//img[@title='Expand']");


			//clickOnEle("xpath", ".//img[@class='bi-tree-view-expand-icon']");

			System.out.println(lstExpands.size());

		}

		//clickOnEle("xpath", ".//td[text()='Native Directory']");



		//		clickOnEle("xpath", ".//td[text()='Users']");

		/*clickOnEle("xpath", ".//td[text()='HFM-VZDEV']");

		Thread.sleep(5000);

		String tableVal=getText("xpath", ".//*[contains(@id,'lcm.mnit_ExploreApp')]");

		System.out.println("table value is "+tableVal);*/

		return this;
	}

	public HomePage validateApplicationManagementOptions() throws Exception

	{

		String tableVal= null;
		
		String tableVal1= null;

		String appName=null;

		WebElement mainTable=createWebElement("xpath", ".//table[@class='bi-tree-view-table']");


		List<WebElement>lstOfRows=createWebElements(mainTable,"tagname", "tr");

		for(int i=0;i<lstOfRows.size()-1;i++)
		{
			lstOfRows=createWebElements(mainTable,"tagname", "tr");			

			List<WebElement>lstOfappNames=createWebElements(lstOfRows.get(i),"tagname", "td");

			appName=lstOfappNames.get(0).getText();

			if(appName.equalsIgnoreCase("VZDEV"))
			{
				clickOnEle(lstOfappNames.get(0));

				System.out.println("clicked on vzdev");

				System.out.println("clicked on application "+appName);

				//Thread.sleep(5000);

				invokeWebDriverWait(120, "visibilityofelementlocated", "xpath",".//div[text()='Artifact List']/parent::div/img[@alt='Close']");	

			}

			else
			{

				clickOnEle(lstOfappNames.get(0));	

				System.out.println("clicked on another app");

				System.out.println("clicked on application "+appName);

				Thread.sleep(5000);

			}

			tableVal=getText("xpath", ".//*[@id='cas.Project.viewPane']");

			System.out.println("table value is "+tableVal);

			System.out.println("in first table");


			if(tableVal.equals("")){
				
				System.out.println("in artifact list");

//				if(existsOrNot("xpath", ".//*[contains(@id,'lcm.mnit_ExploreApp')]")){
				
				if(existsOrNot("xpath", ".//div[text()='Artifact List']/parent::div/img[@alt='Close']")){
					
					System.out.println("in artifact list table");

					 tableVal1=getText("xpath", ".//*[contains(@id,'lcm.mnit_ExploreApp')]");
					 
					 System.out.println("m here in application groups");

					 System.out.println("table1 value is "+tableVal1);

					if(tableVal1.equalsIgnoreCase("")||tableVal1.contains("Name")||tableVal1.contains("Page Size")||tableVal1.contains("Application:")||tableVal1.contains("File System:"))

					{
						ReportExcel.addstep("HFM Application - HealthCheck - Validating directories in Shared Services Console ","User is able to access the required directory",appName+" is accessible","Pass");
						
						clickOnEle("xpath",".//div[text()='Artifact List']/parent::div/img[@alt='Close']");

					} 


					else
					{
						ReportExcel.addstep("HFM Application - HealthCheck - Validating directories in Shared Services Console ","User is able to access the required directory",appName+" is not accessible","Fail");			

						ScreenShotLib.takeScreenshotAndSave("validateOptionsInSharedServices");

						clickOnEle("xpath",".//div[text()='Artifact List']/parent::div/img[@alt='Close']");
					}
				}

				else{
					ReportExcel.addstep("HFM Application - HealthCheck - Validating directories in Shared Services Console ","User is able to access the required directory",appName+" is accessible and it's a component","Pass");
				}

			}
			else{

				if(tableVal.equalsIgnoreCase("")||tableVal.contains("Name")||tableVal.contains("Page Size")||tableVal.contains("Application:")||tableVal.contains("File System:"))

				{
					ReportExcel.addstep("HFM Application - HealthCheck - Validating directories in Shared Services Console ","User is able to access the required directory",appName+" is accessible","Pass");

				}

				else
				{
					ReportExcel.addstep("HFM Application - HealthCheck - Validating directories in Shared Services Console ","User is able to access the required directory",appName+" is not accessible","Fail");			

					ScreenShotLib.takeScreenshotAndSave("validateOptionsInSharedServices");

				}
				

			}
			
		}
		
		clickOnEle("xpath", ".//div[text()='Shared Services']/parent::div/img[@alt='Close']");
		
			return this;


		}

	}



